# Image_processing

Description.
The package image_processing is udes to:
    Processing:
        - Histrogram matching
        - Structural similarity
        - Resize image
    Utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram

## Installation<br><br>

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name<br>

```bash
pip install image-processing-package
```

## Author
Charlly Ribeiro

## License
[MIT](https://choosealicense.com/licenses/mit/)
